import React from 'react';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Image from 'material-ui-image'

const style = {
    flexGrow: 1
}
const NavBar = () => {
    return (
        <div>
            <AppBar position="static">
                <Toolbar>
                    <a className="align-items-center justify-content-center p-3" href="index.html">
						<img src="/images/logo/ikea_logo.svg" className="img-fluid" />
					</a>
                    <Typography variant="h6" style={style}>
                        Card Management Application
                    </Typography>
                    
                </Toolbar>
            </AppBar>
        </div>
    )
}

export default NavBar;
